import React from 'react';
import ReactDOM from 'react-dom';
import {connect} from 'react-redux';
import {getStudList} from "../action/index";
import {deleteStud} from "../action/index";
import {addStud} from "../action/index";
import {updateStud} from '../action/index'
import {bindActionCreators} from 'redux';

class Home extends React.Component
{
    constructor(){
        super();

            this.state={
                sid:'',
                data1:[],
                currData:[],
                editData:[],
                photo:'',
                previewFile:'',
                key:''
            }
    }

    componentWillReceiveProps(nextProps)
    {
        this.setState({
            data1:nextProps.Stud
        })
    }

    handleChange=(e)=>{
        e.preventDefault();

        const {name,value}=e.target;

        let currData=this.state;
        currData[name]=value;

        this.setState({currData});
    }
    fileUpload=(e)=>{
        e.preventDefault();
        var file=e.target.files[0];
        var reader=new FileReader();
        reader.onloadend=()=>{
            this.setState({
                photo:file,
                previewFile:reader.result

            })
        }
        reader.readAsDataURL(file);
    }

    add1=(event)=>{
        event.preventDefault();
        var obj={
            pic:this.state.previewFile,
            ...this.state.currData
        }
        this.props.addStud(obj);
    }
    update1=(event)=>{
        event.preventDefault();
        var obj={
            key:this.state.key,
            id:this.state.sid,
            ...this.state.currData
        }
        this.props.updateStud(obj);
        this.setState({
            isEditing:false
        })
    }
    delete1=(id)=>{
        var obj={
            id:id
        }
        this.props.deleteStud(obj);
    }
    render(){
        let currData=this.state.currData;
        let isEditing=this.state.isEditing;
        console.log("data",this.props.Stud);
        return(
            <div>

                <table border="1">
                    <tr>
                        <td>Name</td>
                        <td>Email</td>
                        <td>Contact</td>

                        <td>Action</td>
                    </tr>
                    {
                        this.state.data1.map((st,i)=>{
                            return(
                                <tr>
                                    <td>{st.name}</td>
                                    <td>{st.email}</td>
                                    <td>{st.contact}</td>
                                    <td><button onClick={()=>{this.delete1(st._id)}}>Delete</button></td>
                                    <td><button onClick={()=>{
                                        this.setState({
                                            sid:st._id,
                                            currData:st,
                                            isEditing:true,
                                            key:i
                                        })
                                    }}>Edit</button></td>

                                </tr>
                            )
                        })

                    }
                </table>

                <form>
                    <table>
                        <tr>
                            <td>Name</td>
                            <td><input type="text" name="name" value={currData.name} onChange={this.handleChange}/></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><input type="text" name="email" value={currData.email} onChange={this.handleChange}/></td>
                        </tr>
                        <tr>
                            <td>Conatct</td>
                            <td><input type="text" name="contact" value={currData.contact} onChange={this.handleChange}/></td>
                        </tr>

                        <tr>
                            {isEditing ?  <td><input type="submit" name="Update" value="Update" onClick={this.update1}/></td> :
                                <td><input type="submit" name="Save" value="Save" onClick={this.add1}/></td>
                               }

                        </tr>
                    </table>
                </form>
            </div>
        )
    }
}
function mapStateToProps(state){
   return{
        Stud:state.list
    }
}
function mapDispatchToProps(dispatch){
   return bindActionCreators({getStudList,deleteStud,addStud,updateStud},dispatch);
}
export default connect(mapStateToProps,mapDispatchToProps)(Home);