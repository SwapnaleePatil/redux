import React from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter,Switch,Route,NavLink} from 'react-router-dom';
import './index.css';
import {Provider} from 'react-redux';
import {createStore,applyMiddleware} from 'redux';
import thunk from 'redux-thunk';
import {composeWithDevTools} from 'redux-devtools-extension';
import Home from './components/Home';
import Login from './components/Login';
import allReducer from './reducer/index';
import {getStudList} from "./action/index";

const store=createStore(allReducer,composeWithDevTools(),applyMiddleware(thunk));

store.dispatch(getStudList());
class App extends React.Component
{
    render(){
        return(
            <header>
                <BrowserRouter>
                    <div>
                        <NavLink exact to="/login">Login</NavLink>
                        <NavLink exact to="/home">Home</NavLink>
                    <Switch>
                        <Route exact path='/login' component={Login}/>
                        <Route exact path='/home' component={Home}/>
                    </Switch>
                    </div>
                </BrowserRouter>
            </header>
        )
    }
}
ReactDOM.render(
    <Provider store={store}>
        <App/>
    </Provider>
    ,document.getElementById('root'));
