var axios=require('axios');

export const getStudList=()=>{
    console.log("IN Action");
    return (dispatch)=>
        {
            axios.get("http://localhost:5151/fetchstud")
                .then((result)=>{
                if(result)
                {
                    dispatch({
                        type:'STUD_LIST',
                        payload:result.data
                    })
                    console.log("Data",result.data);
                }
                }).catch((e)=>{
                console.log('Error',e);
            });
        }
}
export const deleteStud=(obj)=>{
    return (dispatch)=>{
        axios.post("http://localhost:5151/deleteData",obj).then((success)=>{
            if(success)
            {
                console.log('delete Data ',success.data);
                dispatch({
                    type:'STUD_DELETE',
                    payload:success.data
                })
            }
        }).catch((e)=>{
            console.log("Error",e);
        })
    }
}
export const addStud=(obj)=>{
    return (dispatch)=>{
        axios.post("http://localhost:5151/addData",obj).then((success)=>{
            if(success)
            {
                console.log('Add Action  ',success.data)
                dispatch({
                    type:'STUD_ADD',
                    payload:success.data
                })
            }
        }).catch((e)=>{
            console.log(e);
        })
    }
}
export const updateStud=(obj)=>{
    return (dispatch)=>{
     // alert(obj.key)
        axios.post("http://localhost:5151/editData",obj)
            .then((success)=>
            {
               //alert(success.data);
                if(success)
                {
                    dispatch({
                        type:'STUD_EDIT',
                        payload:  success.data,
                         key: obj.key
                        })

                }
            })
            .catch((e)=>{
                console.log("Error",e);
            });
        }
}