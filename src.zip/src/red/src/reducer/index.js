import {combineReducers} from 'redux';
import {getAllStuds} from './studReducer';
const allReducer=combineReducers({list:getAllStuds});
export default allReducer;