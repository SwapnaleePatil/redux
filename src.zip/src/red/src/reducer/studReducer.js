import _ from 'lodash';
export const getAllStuds=(state=[],action)=>{
    switch (action.type)
    {
        case 'STUD_LIST':
            //console.log("In Reducer",action.payload);
            return action.payload;
            break;
        case 'STUD_ADD':
            console.log('Add reducer',action.payload);
            return [...state,action.payload];
            break;
        case 'STUD_EDIT':
            //alert( state[action.payload[action.key]]);
            console.log('UPdate Reducer',action.payload);
            state[action.payload[action.key]]=action.payload
            return _.cloneDeep(state);

        case 'STUD_DELETE':
           // alert(action.payload._id);
            return [...state].filter((dt)=>dt._id!==action.payload._id)
        default :
            return state;
    }
    return state
}