import axios from 'axios';
export const getAllRecord=()=>{
    return (
        dispatch=>{
            return axios.get('http://localhost:5151/fetchstud')
                .then((success) => {
                    if (!success) {
                        console.log("Not Found");
                    }
                    else
                    {
                       dispatch({
                           type:'getAllRecord',
                           success
                       });
                    }
                    //console.log("Data", this.state.detailData);
                })
                .catch((e) => {
                    console.log("error", e)
            })
    })
}

export const getStateAllRecord=payload=>{
    return {
        type:'getStateAllRecord',
        payload
    }
}
export const getCityAllRecord=payload=>{
    return {
        type:'getCityAllRecord',
        payload
    }
}
export const addRecord=payload=>{
    return {
        type: 'addRecord',
        payload
    }
}
export const updateRecord=payload=>{
    return {
        type: 'updateRecord',
        payload
    }
}
export const deleteRecord=payload=>{
    return {
        type: 'deleteRecord',
        payload
    }
}
