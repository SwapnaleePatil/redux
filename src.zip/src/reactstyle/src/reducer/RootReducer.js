import {getAllRecord,addRecord,getCityAllRecord,getStateAllRecord,updateRecord,deleteRecord} from "../action/index";
import _ from 'lodash';

const {combineReducers}=require('redux');

const CrudReduser=(state=[],action)=>{
    switch (action.type)
    {
        case 'getAllRecord':
            return action.success;
        case 'addRecord':
            state.push(action.payload);
            return state;
        case 'updateRecord':
            alert("update");
            state[action.payload.key]=action.payload;
             return state;
        case 'deleteRecord':
            alert("delete");
            state.splice(action.payload,1)
            return _.cloneDeep(state);
        default :
            return state;
    }
}
const stateReduser=(state=[],action)=>{
    switch (action.type)
    {
        case 'getStateAllRecord':
            console.log("In Reduser",action.payload)
            return action.payload;
        default :
            return state;
    }
}
const cityReduser=(state=[],action)=>{
    switch (action.type)
    {
        case 'getCityAllRecord':
            console.log("In Reduser",action.payload)
            return action.payload;
        default :
            return state;
    }
}

const RootReducer=combineReducers(
    {
        user:CrudReduser,
        states:stateReduser,
        city:cityReduser});
export default RootReducer;