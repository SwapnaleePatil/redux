import React, { Component } from 'react';
import {Route,BrowserRouter,NavLink,Prompt,Switch} from 'react-router-dom'

import './App.css';
import Login from './component/login';
import {connect} from 'react-redux'
class Footer extends React.Component
{
    constructor(){
        super()

    }

    render(){
        return(
            <header>
                <BrowserRouter>
                    <div className="footer">
                        <h3>Made by React Trainee</h3>
                    </div>
                </BrowserRouter>
            </header>
        )
    }
}
const mapStateToProps=(state)=>{
    return state;
}
export default connect(mapStateToProps,null)(Footer);
//export default Footer;