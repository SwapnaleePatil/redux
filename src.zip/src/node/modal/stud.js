const mongoose=require('mongoose');
let validator=require('validator');
let bcrypt=require('bcryptjs');

const jwt=require('jsonwebtoken');
mongoose.connect("mongodb://localhost:27017/reactexam");

let studSchema=new mongoose.Schema({
    name:{
        type:String
    },
    age:{
        type:Number
    },
    contact:{
        type:Number
    },
    gender:{
        type:String
    },
    email:{
        type:String,
        validate:{
           validator:validator.isEmail,
            message:'{value} is not valid email'
        }
    },
    password:{
        type:String,
        minlength:6,
        maxlength:32
    },
    hobbies:{
         type:Array
    },
    state:{
        type:String
    },
    city:{
        type:String
    },
    pic:{
        type:String
    },
    flag:{
        type:Boolean,
        default:true
    },
    tokens:[{
        auth:String,
        token:String
    }]
},{
    usePushEach:true
});

studSchema.pre('save',function (next) {
    let stud=this;
    if(stud.isModified('password'))
    {
        bcrypt.genSalt((10,(err,salt)=>{
            bcrypt.hash(stud.password,salt,(err,hash)=>{
                console.log("hash",hash);
                if(err)
                {
                    console.log(err);
                }
                stud.password=hash;
                next();

            })
        }))
    }
    else
    {

        next();
    }
})
studSchema.methods.generateAuthToken=function(){
    var stud=this;
    var access='auth';
    var token=jwt.sign(
        {
            _id:stud._id.toHexString(),
            access
        },
        'abc123'
    ).toString();
    stud.tokens.push({access,token});

    return stud.save().then(()=>{
        console.log("Token",token)
        return token;
    })

}
let stud=mongoose.model('stud',studSchema);
module.exports={stud}