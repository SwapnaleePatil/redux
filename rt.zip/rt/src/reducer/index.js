//import allReducer from './allREducer';
import {combineReducers} from 'redux';
import {studReducer} from "./allREducer";
import {cityReducer} from "./allREducer";
import {stateReducer} from "./allREducer";
import {loginReducer} from "./allREducer";

const allReducer=combineReducers({List:studReducer,State:stateReducer,City:cityReducer,Loging:loginReducer});

export default allReducer;
