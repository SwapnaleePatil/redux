//import {combineReducers} from 'redux';
export const studReducer=(state=[],action)=>{
    switch (action.type){
        case 'GET_DATA':
            return action.payload;
        case 'ADD_DATA':
            return [...state,action.payload];

        case 'EDIT_DATA':
            state[action.payload.key]=action.payload;
            return state;

        case 'DELETE_DATA':
            debugger
            return [...state].filter((dt)=>dt._id!==action.payload._id);

        case 'LOGIN_STUD':
            localStorage.setItem('user',action.payload);
            return action.payload;

        default :
            return state;
    }
    return state;
}
export const cityReducer=(state=[],action)=>{
    switch (action.type){
        case 'GET_CITY':
            return action.payload;
            break;
        default :
            return state;
    }
    return state;
}
export const stateReducer=(state=[],action)=>{
    switch (action.type){
         case 'GET_STATE':
            return action.payload;
            break;
         default :
            return state;
    }
    return state;
}
export const loginReducer=(state=[],action)=>{
    switch (action.type){
        case 'LOGIN_STUD':

            if(action.payload.headers['x-auth']) {
                localStorage.setItem('user', action.payload.headers['x-auth']);
            }
            return action.payload.data;
        default :
            return state;
    }
    return state;
}