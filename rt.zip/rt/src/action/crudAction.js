const axios=require('axios');
export const getData=()=>{
    return (dispatch)=>{
        axios.get('http://localhost:5151/fetchstud')
            .then((success)=>{
            dispatch({
                type:'GET_DATA',
                payload:success.data
            })
            })
            .catch((e)=>{
            console.log("Error",e);
        })
    }
}
export const addData=(obj)=>{
    return (dispatch)=>{
        axios.post('http://localhost:5151/addData',obj)
            .then((success)=>{
                dispatch({
                    type:'ADD_DATA',
                    payload:success.data
                })
            })
            .catch((e)=>{
                console.log("Error",e);
            })
    }
}
export const editData=(obj)=>{
    return (dispatch)=>{
        axios.post('http://localhost:5151/editData',obj)
            .then((success)=>{
                dispatch({
                    type:'EDIT_DATA',
                    payload:obj
                })
            })
            .catch((e)=>{
                console.log("Error",e);
            })
    }
}
export const deleteData=(obj)=>{

    return (dispatch)=>{
        axios.post('http://localhost:5151/deleteData',obj)
            .then((success)=>{
                dispatch({
                    type:'DELETE_DATA',
                    payload:success.data
                })
            })
            .catch((e)=>{
                console.log("Error",e);
            })
    }
}
export const getState=()=>{
    return (dispatch)=>{
        axios.get('http://localhost:5151/fetchstate')
            .then((success)=>{
                dispatch({
                    type:'GET_STATE',
                    payload:success.data
                })
            })
            .catch((e)=>{
                console.log("Error",e);
            })
    }
}
export const getCity=()=>{
    return (dispatch)=>{
        axios.get('http://localhost:5151/fetchcity')
            .then((success)=>{
                dispatch({
                    type:'GET_CITY',
                    payload:success.data
                })
            })
            .catch((e)=>{
                console.log("Error",e);
            })
    }
}
export const login=(obj)=>{
    return (dispatch)=>{
        debugger
        axios.post('http://localhost:5151/loginPassport',obj)
            .then((success)=>{

            dispatch({
                type:'LOGIN_STUD',
                payload:success
            })
        }).catch((e)=>{
            console.log("Error",e);
        })
    }
}