import React from 'react';
import {Table, Button, Modal, FormControl, FormGroup, Radio, Label} from 'react-bootstrap';
import {connect} from 'react-redux';
import {getData, getCity, getState, addData, editData, deleteData} from '../action/crudAction'
import moment from 'moment';
import {bindActionCreators} from 'redux'


class Crud extends React.Component {
    constructor() {
        super();
        this.state = {
            detailData: [],
            name: '',
            age: '',
            contact: '',
            email: '',
            city: '',
            state: '',
            pic: '',
            gender: '',
            dob: '',
            isActive: false,
            cityArr: [],
            stateArr: [],
            curCity: [],
            isEditing: false,
            key: ''
        }

    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            detailData: nextProps.list,
            cityArr: nextProps.city,
            stateArr: nextProps.State
        })
        console.log("State", this.state.stateArr)
    }

    componentWillMount() {
        if (!localStorage.getItem('user')) {
            this.props.history.push('/login');
        }
        else
        {
            this.props.getData();
            this.props.getCity();
            this.props.getState();
        }

    }

    showModal = () => {
        this.setState({
            isActive: true
        })
    }
    closeModal = () => {
        this.setState({
            isActive: false,
            isEditing: false
        })
        this.clearData();
    }
    clearData = () => {
        this.setState({
            name: '',
            age: '',
            contact: '',
            email: '',
            state: '',
            city: '',
            pic: '',
            gender: '',
            dob: ''
        })
    }
    insertRac = () => {
        let formData = new FormData();
        formData.append('name', this.state.name);
        formData.append('age', this.state.age);
        formData.append('contact', this.state.contact);
        formData.append('email', this.state.email);
        formData.append('gender', this.state.gender);
        formData.append('state', this.state.state);
        formData.append('city', this.state.city);
        formData.append('dob', this.state.dob);
        formData.append('pic', this.state.pic);
        this.props.addData(formData);
        this.showModal();
        this.clearData();
    }
    deleteRec = (id) => {
        let obj = {id}
        this.props.deleteData(obj);
    }
    updateRec = (key) => {
        let formData = new FormData();
        formData.append('name', this.state.name);
        formData.append('age', this.state.age);
        formData.append('contact', this.state.contact);
        formData.append('email', this.state.email);
        formData.append('gender', this.state.gender);
        formData.append('state', this.state.state);
        formData.append('city', this.state.city);
        formData.append('dob', this.state.dob);
        formData.append('pic', this.state.pic);
        formData.append('key', key);

        this.props.editData(formData);
        this.showModal();
        this.clearData();

    }
    handleState = (e) => {
        this.setState({
            state: e.target.value
        })
    }
    cityHandle = (event) => {
        this.state.curCity = [];
        let state = event.target.value
        this.state.stateArr.map((s, i) => {
            if (s._id === state) {
                this.state.cityArr.map((c, i) => {
                    if (c.stateid === state) {
                        let {curCity} = this.state;
                        curCity.push(c);
                        this.setState({curCity})
                    }
                })
            }
        })
    }
    editData = (value, key) => {
        this.setState({
            name: value.name,
            age: value.age,
            contact: value.contact,
            email: value.email,
            gender: value.gender,
            state: value.state,
            city: value.city,
            dob: value.dob,
            pic: value.pic,
            isActive: true,
            id: value._id,
            key: key,
            isEditing: true
        });
        this.showModal();
    }

    render() {
        let isEditing = this.state.isEditing;
        //const date = new Date();
        //const formattedDate = moment(this.state.dob).format('MM-dd-yyyy HH:mm:ss.000');
        return (
            <center>
                <div>
                    <div>
                        <Button onClick={this.showModal}>Insert New Record</Button>
                        <Modal show={this.state.isActive} onHide={this.closeModal}>
                            <Modal.Header>
                                Add Student Detail
                            </Modal.Header>
                            <Modal.Body>
                                <Table>
                                    <thead>
                                    <tr>
                                        <td>Student Name:</td>
                                        <td><input type="text" name="sname" onChange={(e) => {
                                            this.setState({name: e.target.value})
                                        }} value={this.state.name} required={true}/></td>
                                    </tr>

                                    <tr>
                                        <td>Student Age:</td>
                                        <td><input type="number" name="age" onChange={(e) => {
                                            this.setState({age: e.target.value})
                                        }} value={this.state.age} required={true}/></td>
                                    </tr>
                                    <tr>
                                        <td>Student Contact:</td>
                                        <td><input type="number" name="contact" onChange={(e) => {
                                            this.setState({contact: e.target.value})
                                        }} value={this.state.contact} required={true}/></td>
                                    </tr>
                                    <tr>
                                        <td>Student Email:</td>
                                        <td><input type="email" name="email" onChange={(e) => {
                                            this.setState({email: e.target.value})
                                        }} value={this.state.email} required={true}/></td>
                                    </tr>
                                    <tr>
                                        <td>Student Gender:</td>
                                        <td>
                                            <input type="radio" name="gender" onChange={(e) => {
                                                this.setState({gender: e.target.value})
                                            }} value="male" checked={this.state.gender === 'male' ? true : false}/>Male
                                            <input type="radio" onChange={(e) => {
                                                this.setState({gender: e.target.value})
                                            }} checked={this.state.gender === 'female' ? true : false} value="female"
                                                   name="gender"/>Female
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Student State:</td>
                                        <td><select name="state" onChange={
                                            (e) => {
                                                this.handleState(e);
                                                this.cityHandle(e)
                                            }}>
                                            {isEditing ? <option defaultValue={this.state.state}>
                                                {this.state.stateArr.map((s, i) => {
                                                    if (s._id === this.state.state) {
                                                        return s.statename
                                                    }

                                                })}</option> : <option>==Select State==</option>}

                                            {
                                                this.state.stateArr.map((s, i) => {
                                                    return <option value={s._id}>{s.statename}</option>

                                                })
                                            }

                                        </select></td>
                                    </tr>
                                    <tr>
                                        <td>Student city:</td>
                                        <td><select name="city" onChange={
                                            (e) => {
                                                this.setState({city: e.target.value})
                                            }}>

                                            {isEditing ?
                                                <option defaultValue={this.state.state}>
                                                    {this.state.cityArr.map((s, i) => {
                                                        if (s._id === this.state.city) {
                                                            return s.cityname
                                                        }

                                                    })}</option>

                                                : <option>==Select City==</option>}

                                            {this.state.curCity.map((c, i) => {
                                                return <option value={c._id}>{c.cityname}</option>

                                            })
                                            }

                                        </select></td>
                                    </tr>
                                    <tr>
                                        <td>Date Of Birth</td>
                                        <td>{
                                            console.log(this.state.dob)
                                        }
                                            <input type='date' name='dob'
                                                   value={this.state.dob}
                                                   onChange={(e) => {
                                                       this.setState({dob: e.target.value})
                                                   }}/></td>
                                    </tr>
                                    <tr>
                                        <td>Image:</td>
                                        <td><input type="file" name="fimg" onChange={(e) => {
                                            this.setState({pic: e.target.files[0]})
                                        }}/></td>
                                        <td><img src={'http://localhost:5151/upload/' + this.state.pic} height="70px"
                                                 width="70px"/></td>
                                    </tr>

                                    </thead>
                                </Table>
                            </Modal.Body>
                            <Modal.Footer>
                                {isEditing ? <Button onClick={this.updateRec}>Update</Button> :
                                    <Button onClick={this.insertRac}>Save</Button>}

                                <Button onClick={this.closeModal}>Close</Button>
                            </Modal.Footer>
                        </Modal>
                    </div>
                    <Table bordered striped hover responsive condensed>
                        <thead>
                        <tr>
                            <td colSpan='10' align='center'>Student Detail</td>
                        </tr>
                        <tr>
                            <td align='center'>Student Name</td>
                            <td align='center'>Age</td>
                            <td align='center'>Contact</td>
                            <td align='center'>Gender</td>
                            <td align='center'>State</td>
                            <td align='center'>City</td>
                            <td align='center'>Date Of Birth</td>
                            <td align='center'>Image</td>
                            <td align='center' colSpan='2'>Action</td>
                        </tr>
                        </thead>
                        <tbody>
                        {
                            this.state.detailData.map((value, index) => {
                                return <tr>
                                    <td align='center'>{value.name}</td>
                                    <td align='center'> {value.age}</td>
                                    <td align='center'>{value.contact}</td>
                                    <td align='center'>{value.gender}</td>
                                    <td align='center'>{
                                        this.state.stateArr.map((s, i) => {
                                            if (s._id === value.state) {
                                                return s.statename
                                            }
                                        })}</td>
                                    <td align='center'>{this.state.cityArr.map((s, i) => {
                                        if (s._id === value.city) {
                                            return s.cityname
                                        }
                                    })}</td>
                                    <td align='center'>{(new Date(value.dob)).toLocaleDateString()}</td>
                                    <td align='center'><img src={"http://localhost:5151/upload/" + value.pic}
                                                            height="70px" width="70px" alt="NO img"/></td>
                                    <td align='center'><Button bsStyle="primary" onClick={
                                        () => {
                                            this.editData(value, index);
                                        }
                                    }>Edit</Button></td>
                                    <td align='center'><Button bsStyle="success" onClick={(e) => {
                                        this.deleteRec(value._id)
                                    }}>Delete</Button></td>
                                </tr>
                            })
                        }

                        </tbody>
                    </Table>
                </div>
            </center>
        )

    }
}

function mapStateToProps(state) {
    return {
        list: state.List,
        State: state.State,
        city: state.City
    }
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators({getData, getState, getCity, addData, editData, deleteData}, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Crud);