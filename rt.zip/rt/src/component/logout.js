import React from 'react';
class Logout extends React.Component
{
    constructor()
    {
        super();
    }

    render()
    {
        localStorage.removeItem('user');
        window.location='/';
        return(
            <h1>Logout</h1>
        )
    }
}

export default Logout;