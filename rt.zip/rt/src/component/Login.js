import React from 'react';
import {Table,Button,Label} from 'react-bootstrap';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {login} from '../action/crudAction';
let msg='',isValid='';
class Login extends React.Component
{
    constructor(){
        super();
        this.state={
            username:'',
            password:'',
            detailData:[]
        }
    }
    componentWillReceiveProps(nextProps){
        msg=''

        if(nextProps.list !== 'success')
        {
            isValid="Invalid Username or Password"
        }
        else
        {
            window.location='/crud';
        }
        this.setState({
            detailData:nextProps.list
        })
        }
        loginUser=()=>{
        if(this.state.username==='' && this.state.password==='') {

            msg="Please Enter Valid Value";
            alert(msg);
        }
         else
         {
             const obj={
            username:this.state.username,
            password:this.state.password
        }
        //console.log(obj);
        this.props.login(obj);
    }


    }
    handleemail=(e)=>{
        //let {username}=this.state
        this.setState({username:e.target.value})
    }
    handlepassword=(e)=>{
        this.setState({password:e.target.value})
    }
    validCheck=(e)=>{
        if(e.target.value==='')
        {
            msg=e.target.name+"Field Required";
        }
    }
    render(){
        return(
            <div>
                <table>
                    <thead>
                    <tr><td colSpan='2' align='center'><Label>Login Detail</Label></td></tr>
                    <tr>
                        <td align='center'><span style={{"color": "red"}}>{isValid}</span></td>

                        <td align='center'><span style={{"color": "red"}}>{msg}</span></td>
                    </tr>
                    <tr><td>UserName</td><td><input type='text' name='email' onChange={(e)=>{
                        this.handleemail(e);
                        this.validCheck(e)
                    }}/></td></tr>
                    <tr><td>Password</td><td><input type='text' name='password' onChange={(e)=>{
                        this.handlepassword(e);
                        this.validCheck(e);
                    }}/></td></tr>
                    <tr><td align='center' colSpan='2'><Button onClick={this.loginUser}  active>Login</Button></td></tr>
                    </thead>
                </table>
            </div>
        )
    }
}
function mapStateToProps(state) {
    console.log("list",state.Loging)
    return {list:state.Loging}
}
function mapDispatchToProps(dispatch) {
    return bindActionCreators({login},dispatch);
}
export default connect(mapStateToProps,mapDispatchToProps)(Login);