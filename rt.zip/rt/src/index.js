import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import {createStore,applyMiddleware} from 'redux';
import {Provider} from 'react-redux';
import thunk from 'redux-thunk';
import {BrowserRouter,Route,NavLink,Switch} from 'react-router-dom';
import Login from './component/Login';
import Crud from './component/Crud';
import Logout from './component/logout';
import {Button} from 'react-bootstrap';
import allReducer  from './reducer/index'
import {composeWithDevTools} from 'redux-devtools-extension';
const store=createStore(allReducer,composeWithDevTools(),applyMiddleware(thunk));
class App extends React.Component
{
    render(){
        return(
            <header>
            <BrowserRouter>
                <div className='cl' align='center'>
                    {
                        localStorage.getItem('user')===null?
                            <Button active><NavLink to='/' exact>Login</NavLink></Button>:
                            <Button active><NavLink to='/logout' exact>Logout</NavLink></Button>
                    }
                    <Button active><NavLink to='/crud' exact>EmployeeCrud</NavLink></Button>
                    <Switch>
                        <Route path='/logout' exact component={Logout}/>
                        <Route path='/' exact component={Login}/>
                        <Route path='/crud' exact component={Crud}/>
                    </Switch>
                </div>
            </BrowserRouter>
            </header>
        )
    }
}
ReactDOM.render(<Provider store={store}><App /></Provider>, document.getElementById('root'));
