import React from 'react';
import '../App.css';
import {connect} from 'react-redux';
import Table from "../table";


class Form extends React.Component {
    constructor(props){
        super(props);
        this.state={
            isChanged:false
        }
    }

    // componentWillMount() {
    //     if(!localStorage.getItem('user'))
    //     {
    //         this.props.history.push('/login');
    //     }
    // }
    render(){
        return(
            <Table />
        )
    }
}
const mapStateToProps=(state)=>{
    return state;
}
export default connect(mapStateToProps,null)(Form);
//export default Form;
