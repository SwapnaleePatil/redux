import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import Login from "./component/login";
import {createStore} from 'redux';
import {composeWithDevTools} from 'redux-devtools-extension'
import {Provider} from 'react-redux';
import RootReducer from "./reducer/RootReducer";
import TableData from "./component/TableDisp";
import ExamC from "./component/examCrud"
let store=createStore(RootReducer,composeWithDevTools());
console.log("store",store)
ReactDOM.render(<Provider store={store}><App method={store}/></Provider>, document.getElementById('root'));


//ReactDOM.render(<App />, document.getElementById('root'));

