
export const getAllRecord=payload=>{
    return {
        type:'getAllRecord',
        payload
    }
}
export const getStateAllRecord=payload=>{
    return {
        type:'getStateAllRecord',
        payload
    }
}
export const getCityAllRecord=payload=>{
    return {
        type:'getCityAllRecord',
        payload
    }
}
export const addRecord=payload=>{
    return {
        type: 'addRecord',
        payload
    }
}
export const updateRecord=payload=>{
    return {
        type: 'updateRecord',
        payload
    }
}
export const deleteRecord=payload=>{
    return {
        type: 'deleteRecord',
        payload
    }
}
