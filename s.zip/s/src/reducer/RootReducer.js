import {getAllRecord,addRecord,getCityAllRecord,getStateAllRecord,updateRecord,deleteRecord} from "../action/index";
import _ from 'lodash';

const {combineReducers}=require('redux');

const CrudReduser=(state=[],action)=>{
    switch (action.type)
    {
        case 'getAllRecord':
         //   debugger;
            return action.payload;
        case 'addRecord':
           // let st = _.cloneDeep(state);
            state.push(action.payload);
            return state;
           // return action.payload;
        case 'updateRecord':
            action.payload.key=action.payload;
             return state;
        case 'deleteRecord':
            //let id=action.payload.id;
            state.splice(action.payload.key,1)
            return state;
        default :
            return state;
    }
}
const stateReduser=(state=[],action)=>{
    switch (action.type)
    {
        case 'getStateAllRecord':
            console.log("In Reduser",action.payload)
            return action.payload;
        default :
            return state;
    }
}
const cityReduser=(state=[],action)=>{
    switch (action.type)
    {
        case 'getCityAllRecord':
            console.log("In Reduser",action.payload)
            return action.payload;
        default :
            return state;
    }
}

const RootReducer=combineReducers(
    {
        user:CrudReduser,
        states:stateReduser,
        city:cityReduser});
export default RootReducer;