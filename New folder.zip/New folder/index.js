const expree = require("express");

const {stud} = require('./modal/stud');
const passport=require('passport');
const LocalStrategy=require('passport-local');
const {state1} = require('./modal/state');
const {city} = require('./modal/city');
const bodyParser = require('body-parser');
const _ = require('lodash');
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');
var app = expree();
const expUpload=require('express-fileupload');
app.use(expUpload())
app.use(expree.static(__dirname+'/'));
var token='';


//const localStorage=require('node-localstorage');
app.use(bodyParser.json());
app.use((req, res, next) => {

    res.header('Access-Control-Allow-Origin','*');
    res.header("Access-Control-Allow-Headers", "Access-Control-*, Origin, X-Requested-With, Content-Type, Accept,x-auth");

    res.header("Access-Control-Allow-Credentials",true);
    res.header(`Access-Control-Allow-Methods`, `POST`);
    res.header(`Access-Control-Allow-Methods`, `DELETE`);
    res.header(`Access-Control-Allow-Methods`, `PATCH`);
    res.header(`Access-Control-Expose-Headers`, `x-auth`);
    next();
});
app.get('/', (req, res) => {
    res.send("Hello");
})

//Passport
app.use(passport.initialize());

passport.serializeUser((emp,done)=>{
    return done(null,emp);
})
passport.deserializeUser((emp,done)=>{
    return done(null,emp);
})
passport.use(new LocalStrategy ((username,password,done)=>{
    console.log('USer',username,password);
    stud.findOne({email:username},(err,user)=>{
        if(err)
        {
            console.log("Error",err);
        }
        if(!user)
        {
            console.log("Not Get");
            return done (null,false)
        }
        else
        {
            bcrypt.compare(password,user.password,(err,result)=>{
                if(err)
                {
                    console.log("Error Found");

                }
                if(result)
                {
                    token=user.tokens[0].token;
                    return done(null,user);
                }
                else
                {
                    return done(null,false);
                }
            })
        }
    })


}));
app.post('/loginPassport',passport.authenticate('local',{
    successRedirect:'/loginSuccess',
    failureRedirect:'/loginFailure'
}));
app.get('/loginSuccess',(req,res)=>{
   return res.header('x-auth',token).send('success');
})
app.get('/loginFailure',(req,res)=>{
    res.send("User Not Found");
})
//Stud
app.post('/addData', (req, res) => {
    console.log("Ass",req.body);
   var dob=new Date(req.body.dob);
    var sampleFiles=req.files.pic;
    sampleFiles.mv(__dirname+'/upload/'+sampleFiles.name)
    var newStud = new stud({
        name:req.body.name,
        age:req.body.age,
        contact:req.body.contact,
        gender:req.body.gender,
        email:req.body.email,
        state:req.body.state,
        city:req.body.city,
        pic:sampleFiles.name,
        dob:dob
    });
    newStud.save().then(()=>{
        return newStud.generateAuthToken();
    }).then((token)=>{
        res.header('x-auth',token).send(newStud);
    }).catch((e)=>{
        console.log("Error",e);
    })

})
app.post('/editData', (req, res) => {
    // let body = _.pick(req.body, ['id','name', 'age', 'contact', 'gender', 'email', 'password', 'hobbies', 'state', 'city', 'pic']);
    let id = req.body.id;
    var dob=new Date(req.body.dob);
    console.log(req.body);
    stud.findById(id).then((stud) => {
            stud.name=req.body.name,
            stud.age=req.body.age,
            stud.contact=req.body.contact,
            stud.gender=req.body.gender,
            stud.email=req.body.email,
            stud.state=req.body.state,
            stud.city=req.body.city,
           // stud.pic=sampleFiles.name,
            stud.dob=dob
        if(req.files!==null){
            var sampleFile=req.files.pic
            sampleFile.mv(__dirname+'/upload/'+sampleFile.name)
            stud.pic=sampleFile.name
        }


        stud.save().then(()=>{
            res.send(stud);
        })
    }).catch((e) => {
        console.log("Error", e);
    })
 });
app.post('/deleteData', (req, res) => {
    let id=req.body.id;
    stud.findByIdAndUpdate(id,{$set:{flag:false}}).then((stud)=>{
        (!stud)
        {
            console.log("Stud Not Found");
        }
        res.send(stud);
    }).catch((e)=>{
        console.log("Error",e);
    })

})
app.get('/fetchstud',(req,res)=>{
    stud.find({flag:'true'}).then((stud)=>{
        (stud)
        {
            // console.log("Stud ",stud)

        }
        res.send(stud);
    })
        .catch((e)=>{
            console.log("Error",e);
        })
})
//state
app.post('/addstate', (req, res) => {
    console.log("Hello");
    console.log("Body", req.body);
    let body = _.pick(req.body, ['statename']);
    var newstate = new state1(body);

    newstate.save().then((state) => {
        if (!state) {
            console.log("Stud Not Found")
        }
        res.send(state);
    }).catch((e) => {
        console.log(`Error is {e}`)
    })

})
app.get('/fetchstate',(req,res)=>{
    state1.find({}).then((state)=>{
        (!state)
        {
            console.log("state Not Found")
        }
        res.send(state);
    })
        .catch((e)=>{
            console.log("Error",e);
        })
})
//city
app.post('/addcity', (req, res) => {
    console.log("Hello");
    console.log("Body", req.body);
    let body = _.pick(req.body, ['cityname', 'stateid']);
    var newcity = new city(body);

    newcity.save().then((city) => {
        if (!city) {
            console.log("city Not Found")
        }
        res.send(city);
    }).catch((e) => {
        console.log(`Error is {e}`)
    })

})
app.get('/fetchcity',(req,res)=>{
    city.find({}).then((city)=>{
        (city)
        {
            console.log("city Not Found")
        }
        res.send(city);
    })
        .catch((e)=>{
            console.log("Error",e);
        })
})
app.listen(5151);

