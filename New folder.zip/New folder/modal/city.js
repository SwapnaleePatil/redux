const mongoose=require('mongoose');
mongoose.connect("mongodb://localhost:27017/reactexam");
var citySchema=new mongoose.Schema({
    cityname:{
        type:String
    },
    stateid:{
        type:String
    },
    contact:{
        type:Number
    }
})

var city=mongoose.model('city',citySchema);
module.exports={city}